# nathanpitman.com — Astro site

Personal blog and portfolio. Built with [Astro](https://astro.build), deployed
to GitHub Pages via GitHub Actions.

---

## Replit setup prompt

Paste this prompt into Replit when importing this project:

> This is an Astro static site project. Please:
> 1. Run `npm install` to install dependencies.
> 2. Configure the Run button to execute `npm run dev -- --host 0.0.0.0` so the
>    dev server is accessible in the Replit preview pane.
> 3. The site should be previewable inside Replit at any time using the dev server.
> 4. When I'm ready to publish, I'll push to GitHub and the Actions workflow in
>    `.github/workflows/deploy.yml` will build and deploy to GitHub Pages automatically.
> 5. Do not modify the existing Astro component structure or CSS unless I ask you to.

---

## Project structure

```
src/
  layouts/
    BaseLayout.astro      ← shared HTML shell, nav, footer (edit nav items here)
  components/
    Sidebar.astro         ← sidebar for journal + about pages
    SidebarArchives.astro ← sidebar for the archives page
  pages/
    index.astro           ← journal / recently
    archives.astro        ← post archive grouped by year/month
    about.astro           ← biographical about page
  styles/
    main.css              ← all styles, heavily commented by section
public/
  avatar.jpg              ← profile photo (replace to update)
  images/                 ← post and page images go here
.github/
  workflows/
    deploy.yml            ← GitHub Actions: build + deploy to Pages on push to main
astro.config.mjs          ← Astro configuration (set `site` to your domain)
```

---

## Common tasks

### Add a new journal post
Open `src/pages/index.astro` and duplicate an `<article class="post">` block.
Update the title, date, body and tags. Add the post to the top of the archives
array in `src/pages/archives.astro` and to the `recentPosts` array in
`src/components/SidebarArchives.astro`.

### Update nav links
Edit `src/layouts/BaseLayout.astro`.

### Update sidebar content
- Journal + about sidebar: `src/components/Sidebar.astro`
- Archives sidebar: `src/components/SidebarArchives.astro`

### Change styles
All CSS is in `src/styles/main.css`, divided into clearly labelled sections.

### Replace the avatar photo
Drop a new `avatar.jpg` into `public/` (same filename, any size — it renders at 56×56px).

### Add post images
Place images in `public/images/` and reference them as `/images/your-image.jpg`.

---

## Local development

```bash
npm install
npm run dev
```

Open http://localhost:4321 in your browser.

---

## Deploy

Push to the `main` branch. GitHub Actions will build and publish automatically.

Make sure GitHub Pages is enabled in your repo settings:
**Settings → Pages → Source → GitHub Actions**

Update `site` in `astro.config.mjs` to match your GitHub Pages URL or custom domain.

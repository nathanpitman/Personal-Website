// astro.config.mjs
import { defineConfig } from 'astro/config';

export default defineConfig({
  // Set this to your GitHub Pages URL once deployed,
  // e.g. 'https://nathanpitman.github.io' or your custom domain.
  site: 'https://nathanpitman.github.io',

  // If deploying to a project page (not a user/org page) set base:
  // base: '/your-repo-name',
  // Leave blank / remove if using a custom domain or user page.

  output: 'static',
});
